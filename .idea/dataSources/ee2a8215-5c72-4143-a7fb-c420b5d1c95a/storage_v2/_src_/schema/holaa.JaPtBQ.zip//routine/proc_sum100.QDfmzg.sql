create
    definer = root@localhost procedure proc_sum100(OUT total int)
BEGIN
		declare num int default 0;
		set total =0;
		while num<=100 DO
		set total=total+num;
		set num=num+1;
	END WHILE;
END;

